<?php

header('Content-disposition: attachment; filename=factsheet-Intersect_ENT_Company_v2012-06-12.pdf');
header('Content-type: application/pdf');
readfile('factsheet-Intersect_ENT_Company_v2012-06-12.pdf');

?>