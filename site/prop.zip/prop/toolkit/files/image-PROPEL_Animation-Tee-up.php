<?php

header('Content-disposition: attachment; filename=image-PROPEL_Animation-Tee-up.jpg');
header('Content-type: application/jpg');
readfile('image-PROPEL_Animation-Tee-up.jpg');

?>