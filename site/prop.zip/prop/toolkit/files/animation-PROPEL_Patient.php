<?php

header('Content-disposition: attachment; filename=animation-PROPEL_Patient.mov');
header('Content-type: application/mov');
readfile('animation-PROPEL_Patient.mov');

?>