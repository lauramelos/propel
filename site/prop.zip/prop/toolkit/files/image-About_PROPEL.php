<?php

header('Content-disposition: attachment; filename=image-About_PROPEL.jpg');
header('Content-type: application/jpg');
readfile('image-About_PROPEL.jpg');

?>