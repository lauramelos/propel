<?php

header('Content-disposition: attachment; filename=factsheet-PROPEL_v2012-06-12.pdf');
header('Content-type: application/pdf');
readfile('factsheet-PROPEL_v2012-06-12.pdf');

?>