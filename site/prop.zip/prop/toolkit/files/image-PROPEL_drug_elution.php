<?php

header('Content-disposition: attachment; filename=image-PROPEL_drug_elution.tif');
header('Content-type: application/tif');
readfile('image-PROPEL_drug_elution.tif');

?>