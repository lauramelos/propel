<?php

header('Content-disposition: attachment; filename=image-PROPEL_product.jpg');
header('Content-type: application/jpg');
readfile('image-PROPEL_product.jpg');

?>